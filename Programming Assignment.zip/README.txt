Hemant Sherawat
COMP 3270-D01
July 17, 2021
Dr. Yilmaz

Name of all files in the archive:
	HemantSherawat_phw_output.txt
	phw_input.txt
	Programming HW graphs.xlsx
	Programming HW submission - HemantSherawat.pdf
	ProgrammingHW_v2.class
	ProgrammingHW_v2.java
	README.txt

Compilation instructions:
	This program was created and compiled in jGrasp IDE, 
	as such the jGrasp IDE can be used to verify the functioning of this program.

Certification:
	I certify that I wrote the code I am submitting. I did not copy whole or parts of it from another student or 
	have another person write the code for me. Any code I am reusing in my program is clearly marked as such
	with its source clearly identified in comments.