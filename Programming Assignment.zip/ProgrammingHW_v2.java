/*
 *Name:     Hemant Sherawat
 *Course:   COMP 3270-D01
 *Date:     07/17/2021
 *Project:  Programming HW Version 2.0 created and compiled in jGrasp IDE
 *
 *Changes from version 1.0:
 *1) Unnescessary comments and code used for output testing removed.
 *
 *References:
 *1) Reveiwed general Java programming concepts from COMP 1210 by Dr. James Cross
 *2) Reading CSV files: https://stackabuse.com/reading-and-writing-csvs-in-java/
 *3) Generating random number in a range: https://www.baeldung.com/java-generating-random-numbers-in-range           
 *4) Creating multiple arraylists: https://stackoverflow.com/questions/44226004/java-creating-multiple-arraylist
 *5) Measuring elapsed time: https://www.baeldung.com/java-measure-elapsed-time
 *6) Writing to a file: https://www.baeldung.com/java-write-to-file
 *
 *Compilation instructions:
 *1) This program was created and compiled in jGrasp IDE, so the best recommmendation would be to use the same
 *   software to compile and run this program.
 *2) phw_input.txt should be in the same directory as the program for the program to run correctly.
 *
 */

import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.lang.System;
import java.util.Random;
       
class ProgrammingHW_v2 {
   public static void main(String[] args) throws IOException {
      ArrayList<Integer> input_list = new ArrayList<Integer>(); //Array list is used for its resizable properties
      
      /******Start of 5.******/
      //Reading file phw_input.txt
      //Reference 2 used
      File input_file = new File("phw_input.txt"); //read file
      BufferedReader reader = new BufferedReader(new FileReader(input_file));
      
      String line;
      while((line = reader.readLine()) != null) {  
         String[] split = line.split(",");         //split line into chunks
         for(String str : split) {
            int temp = Integer.parseInt(str);      //convert string chunks to int
            input_list.add(temp);
         }
         System.out.println("Integers extracted from file: \n\t" + input_list);     
      }
      reader.close();
      
      System.out.println("MSCS determined by each of the algorithms for the input file are as follows: ");
      System.out.println("Algorithm-1:\t" + algorithm_one(input_list));
      System.out.println("Algorithm-2:\t" + algorithm_two(input_list));
      System.out.println("Algorithm-3:\t" + maxSum(input_list, 0, input_list.size() - 1));
      System.out.println("Algorithm-4:\t" + algorithm_four(input_list));
      /******End of 5.******/
   
      /******Start of 6.*****/
      //Generate 19 arrays with sizes varing from 10, 15, 20, ...95, 100, containing randomly generated integers
      //Reference 3 and 4 used         
      ArrayList<Integer> A[] = new ArrayList[19]; 
         //Create an array of ArrayLists to simulate a two dimensional matrix with fixed number of rows but with flexible column sizes
      
      for (int i = 0; i < 19; i++) {
         A[i] = new ArrayList<Integer>();          //Create an ArrayList at A[i]
         for (int j = 0; j < (i + 2) * 5; j++) {   //Max limit of j will vary with i   
                                                   //Generate random numbers and add them to A[i] 
            int random_number = randomIntegerGenerator(-500, 500);
            A[i].add(random_number);
         }
      }
      /******Break 6.******/
   
      /******Start of 7.******/
      //Using system clocks to measure average times t1, t2, t3 and t4 and store in first 4 columns of output matrix
      //References 4 and 5 used 
      ArrayList<Double> matrix[] = new ArrayList[19];
      
      int N = 500;                              //each algorithm runs 500 times
      for(int i = 0; i < 19; i++) {
         matrix[i] = new ArrayList<Double>();
         double sum_t1 = 0;
         double sum_t2 = 0;
         double sum_t3 = 0;
         double sum_t4 = 0;
         for(int k = 0; k < N; k++) {
            long start = System.nanoTime();
            algorithm_one(A[i]); 
            long finish = System.nanoTime();
            long time_elapsed = finish - start;
            sum_t1 += time_elapsed;
               
            start = System.nanoTime();
            algorithm_two(A[i]); 
            finish = System.nanoTime();
            time_elapsed = finish - start;
            sum_t2 += time_elapsed;
               
            start = System.nanoTime();
            maxSum(A[i], 0, (A[i].size() - 1)); 
            finish = System.nanoTime();
            time_elapsed = finish - start;
            sum_t3 += time_elapsed;
               
            start = System.nanoTime();
            algorithm_four(A[i]); 
            finish = System.nanoTime();
            time_elapsed = finish - start;
            sum_t4 += time_elapsed;
         }
         double avg_t1 = sum_t1 / N;
         double avg_t2 = sum_t2 / N;
         double avg_t3 = sum_t3 / N;
         double avg_t4 = sum_t4 / N;

         matrix[i].add(0, avg_t1);
         matrix[i].add(1, avg_t2);
         matrix[i].add(2, avg_t3);
         matrix[i].add(3, avg_t4);  
         /******End of 7.******/
   
         /******Start of 8.******/
         //Calculate T1(n), T2(n), T3(n) and T4(n) and store in last four columns of output matrix
         for (int j = 0; j < 4; j++) {  
            double T = complexity(A[i].size(), j);
            matrix[i].add(j + 4, T);  
         }
         //System.out.println(matrix[i]); 
         /******Break 8.******/
      }
      
      /******Start of 9.******/
      //Write output matrix to an output file
      //Reference 6 used
      BufferedWriter writer = new BufferedWriter(new FileWriter("HemantSherawat_phw_output.txt"));
      String str = "Algorithm-1,Algorithm-2,Algorithm-3,Algorithm-4,T1(n),T2(n),T3(n),T4(n)";
      writer.write(str);
      
      for(int i = 0; i < 19; i++) {
         writer.append("\n");
         for(int j = 0; j < 8; j++) {
            str = String.valueOf(matrix[i].get(j));
            writer.append(str);
            if(j != 7)   
               writer.append(",");
         }
      }
      writer.close();
      System.out.println("\nOutput file named HemantSherawat_phw_output.txt with measured and predicted times has been generated!");
      /******End of 9.******/
   }
   
   /******Continue 8.******/
   //Complexity function, accepts n and algorithm index as argument and returns ceiling value of T(n)
   public static double complexity(int n, int algorithm_i) {
      double T = 0;
      if (algorithm_i == 0)
         T = 6 + ((7/6)*n*n*n) + ((41/6)*n) + (7*n*n);
      else if (algorithm_i == 1)
         T = (6*n*n) + (8*n) + 5;
      else if (algorithm_i == 2)
         T = (12*n*n) + (37*n) - 38;
      else if (algorithm_i == 3)
         T = (14*n) + 5;
      
      return Math.ceil(T);
   }
   /******End of 8.******/
   
   //*****Start of 1.******/
   //Implement algorithms
   
   public static int max(int a, int b) {        //find largest between two numbers
      int largest = 0;
      if (a >= b)
         largest = a;
      else if (b > a)
         largest = b;
         
      return largest;
   }
   
   public static int max(int a, int b, int c) { //find largest between three numbers (max function is overloaded)
      int largest = 0;
      if (a >= b && a >= c)
         largest = a;
      else if (b >= a && b >= c)
         largest = b;
      else if (c >= a && c >= b)
         largest = c;
      
      return largest;
   }
   
   public static int algorithm_one(ArrayList<Integer> X) {
      int maxSoFar = 0;
      int P = 0;
      int Q = X.size();
      int sum;
      
      for(int L = P; L < Q; L++) {
         for(int U = L; U < Q; U++) {
            sum = 0;
            for(int I = L; I <= U; I++)   //I < U does not work
               sum = sum + X.get(I);      //sum now contains the sum of X[L..U]
            maxSoFar = max(maxSoFar, sum);
         }
      }
      return maxSoFar;
   }
   
   public static int algorithm_two(ArrayList<Integer> X) {
      int maxSoFar = 0;
      int P = 0;
      int Q = X.size();
      int sum;
      
      for(int L = P; L < Q; L++) {
         sum = 0;
         for(int U = L; U < Q; U++) {
            sum = sum + X.get(U);         //sum now contains the sum of X[L..U]
            maxSoFar = max(maxSoFar, sum);
         }
      }
      return maxSoFar;
   }
   
   //Algorithm Three RECURSIVE FUNCTION
   public static int maxSum(ArrayList<Integer> X, int L, int U) {
      if (L > U)
         return 0;                        //zero element vector
      if (L == U)
         return max(0, X.get(L));         //one element vector         
      
      int M = (L + U) / 2;                //A is X[L..M], B is X[M+1..U]
      
      //Find max crossing to left
      int sum = 0;
      int maxToLeft = 0;
      for(int I = M; I >= L; I--) {
         sum = sum + X.get(I);
         maxToLeft = max(maxToLeft, sum);
      }
      
      //Find max crossing to right
      sum = 0;
      int maxToRight = 0;
      for(int I = M + 1; I <= U; I++) {
         sum = sum + X.get(I);
         maxToRight = max(maxToRight, sum);
      }
      
      int maxCrossing = maxToLeft + maxToRight;
      
      int maxInA = maxSum(X, L, M);
      int maxInB = maxSum(X, (M + 1), U);
      return max(maxCrossing, maxInA, maxInB);       
   }
     
   public static int algorithm_four(ArrayList<Integer> X) {
      int maxSoFar = 0;
      int maxEndingHere = 0;
      int P = 0;
      int Q = X.size();
      
      for (int I = P; I < Q; I++) {
         maxEndingHere = max(0, maxEndingHere + X.get(I));
         maxSoFar = max(maxSoFar, maxEndingHere);
      }
           
      return maxSoFar;
   }
   /******End of 1.******/
   
   /******Continue 6.******/
   //Random generator function, accepts min and max values of a range as arguments and returns a random number within that range
   //Reference 3 used almost verbatim  
   public static int randomIntegerGenerator(int min, int max) {
      return (int) ((Math.random() * (max - min)) + min);
   }
   //*****End of 6.******/
}    
